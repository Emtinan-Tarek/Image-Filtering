using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using ZGraphTools;

namespace ImageFilters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        byte[,] ImageMatrix;
        string OpenedFilePath;
        private void btnOpen_Click(object sender, EventArgs e)
        {
            label5.Text = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Open the browsed image and display it
                OpenedFilePath = openFileDialog1.FileName;
                ImageMatrix = ImageOperations.OpenImage(OpenedFilePath);
                ImageOperations.DisplayImage(ImageMatrix, pictureBox1);

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            label5.Text = "";
            if (OpenedFilePath == null)
                return;
            ImageMatrix = ImageOperations.OpenImage(OpenedFilePath);
            string Text = textBox1.Text;
            string Text_Filter = comboBox1.Text;
            string Text_Sort = comboBox2.Text;
            if (Text_Sort.Length == 0)
                Text_Sort = "0";
            int Sort = Text_Sort[0] - '0';
            if (Text_Filter.Length == 0)
                Text_Filter = "1";
            int Filter = Text_Filter[0] - '0';
            for (int i = 0; i < Text.Length; i++)
            {
                if (Text[i] >= '0' && Text[i] <= '9')
                    continue;
                else
                    return;
            }
            if (Text.Length == 0)
                return;
            int Max_Size = int.Parse(Text);
            int Start = System.Environment.TickCount;
            ImageOperations.ImageFilter(ImageMatrix, Max_Size, Sort, Filter);
            int End = System.Environment.TickCount;
            ImageOperations.DisplayImage(ImageMatrix, pictureBox2);
            double Time = End - Start;
            Time /= 1000;
            label5.Text = (Time).ToString();
            label5.Text += " s";
        }

        private void btnZGraph_Click(object sender, EventArgs e)
        {
            if (OpenedFilePath == null)
                return;
            ImageMatrix = ImageOperations.OpenImage(OpenedFilePath);
            string Text = textBox1.Text;
            string Text_Filter = comboBox1.Text;
            string Text_Sort = comboBox2.Text;
            if (Text_Sort.Length == 0)
                Text_Sort = "0";
            int Sort = Text_Sort[0] - '0';
            if (Text_Filter.Length == 0)
                Text_Filter = "1";
            int Filter = Text_Filter[0] - '0';
            
            for (int i = 0; i < Text.Length; i++)
            {
                if (Text[i] >= '0' && Text[i] <= '9')
                    continue;
                else
                    return;
            }
            if (Text.Length == 0)
                return;
            int Max_Size = int.Parse(Text);
            
            int z = 0;
            int number = 3;

            double[] x_values = new double[Max_Size];
            double[] y_values_count_alpha = new double[Max_Size];
            double[] y_values_kth = new double[Max_Size];
            double[] y_values_quick = new double[Max_Size];
            double[] y_values_count_Adaptive = new double[Max_Size];

            

            do
            {
                x_values[z] = number;
                number +=2;
                z++;
            }while(number <= Max_Size);

            z=0;
            number = 3;
            while (number <= Max_Size)
            {
                long start1 = Stopwatch.GetTimestamp();
                ImageOperations.ImageFilter(ImageMatrix, number, 3, 1);
                long end1 = Stopwatch.GetTimestamp();
                long Time_kth = end1 - start1;

                long start2 = Stopwatch.GetTimestamp();
                ImageOperations.ImageFilter(ImageMatrix, number, 2, 1);
                long end2 = Stopwatch.GetTimestamp();
                long Time_count = end2 - start2;

                long start3 = Stopwatch.GetTimestamp();
                ImageOperations.ImageFilter(ImageMatrix, number, 1, 2);
                long end3 = Stopwatch.GetTimestamp();
                long Time_quick = end3 - start3;

                long start4 = Stopwatch.GetTimestamp();
                ImageOperations.ImageFilter(ImageMatrix, number, 2, 2);
                long end4 = Stopwatch.GetTimestamp();
                long Time_count_adaptive = end4 - start4;


                y_values_kth[z] = (double)Time_kth;
                y_values_count_alpha[z] = (double)Time_count;
                y_values_quick[z] = (double) Time_quick;
                y_values_count_Adaptive[z] = (double) Time_count_adaptive;
                number +=2;
                z++;
            }
            
            //Create a graph and add two curves to it
            ZGraphForm ZGF1 = new ZGraphForm("Alpha-trim filter", "Window Size", "Execution Time");
            ZGraphForm ZGF2 = new ZGraphForm("Adaptive median filter", "Window Size", "Execution Time");
            ZGF1.add_curve("Counting Sort", x_values, y_values_count_alpha,Color.Red);
            ZGF1.add_curve("Kth Smallest/Largest Element", x_values, y_values_kth,Color.Blue);
            ZGF1.Show();
            ZGF2.add_curve("Counting Sort", x_values, y_values_count_Adaptive,Color.Green);
            ZGF2.add_curve("Quick Sort", x_values, y_values_quick,Color.Purple);
            ZGF2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}